public func prepareScene(){
    let scene = startScene()  //Função em Contents/Sources/Starter.swift
    //scene.prepareFlags(n: 6)
    scene.prepareFlags(numbers: [3,1,6,2,0,4,5])
}
