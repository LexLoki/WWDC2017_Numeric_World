// 
//  LiveView.swift
//
//  Copyright (c) 2016 Apple Inc. All Rights Reserved.
//

// Quando se deseja uma tela que rode permanentemente (não só quando o usuário entra "Run Code") deve-se implementar sua inicialização neste arquivo.
// O código aqui é executado somente uma vez, ao entrar na página, enquanto o código de "Contents.swift" é executado sempre que o usuário selecionar  "Run Code".

prepareScene() //Função definida em "Sources/Setup.swift" desta page
