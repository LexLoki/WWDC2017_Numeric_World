public func prepareScene(){
    let scene = startScene()
    scene.prepareFlags(n: 8, putZero: true)
}
